package TELSTRA_TESTPACKAGE;



import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/test/resources"},
 glue = { "TELSTRA_StepDefinition" }, tags = {"@tag"}
        )
public class TELSTRA_RunnerClass {
	
	
}
