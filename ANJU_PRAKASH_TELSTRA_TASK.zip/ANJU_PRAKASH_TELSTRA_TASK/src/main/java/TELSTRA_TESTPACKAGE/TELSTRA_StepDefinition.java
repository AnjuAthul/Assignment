package TELSTRA_TESTPACKAGE;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.spi.RepositorySelector;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.qameta.allure.Allure;
public class TELSTRA_StepDefinition {
	
	
	public static WebDriver driver;
	public  RespositoryParser parser ;;

	@Given("User is on flipkart home page")
@Given("User is on flipkart home page in {string} browser")
public void user_is_on_flipkart_home_page_in_browser(String browser) throws IOException {
	parser = new RespositoryParser("C:\\Users\\ATHUL\\eclipse-workspace\\ANJU_PRAKASH_TELSTRA_TASK\\src\\main\\java\\TELSTRA_TESTPACKAGE\\ObjectRepo.properties");
	   if(browser.contains("Chrome"))
			{
			   System.out.println(parser.getvalue("chromedriver"));
				System.setProperty(parser.getvalue("chromedriver"), parser.getvalue("chromedriverpath"));
				driver = new ChromeDriver();
			}else if(browser.contains("Firefox")) {
				System.setProperty(parser.getvalue("firefoxdriver"), parser.getvalue("firefoxpath"));
				driver = new FirefoxDriver();
			}
		driver.get("https://www.flipkart.com/");
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		}

@When("the user clicks {string} item")
@When("the user clicks {string} button")
public void the_user_clicks_button(String string) {
	WebElement logn=  driver.findElement(parser.getbjectLocator(string));
	((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+logn.getLocation().y+")");
	logn.click();

}
@Given("user enter the {string} in the {string} session")
@When("user enter the {string} in the {string} session")
public void user_enter_the_in_the_session(String string,String string1) {
	 driver.findElement(parser.getbjectLocator(string1)).sendKeys(parser.getvalue(string));
}
@Given("user is in the successful login page")
@Then("user should be able to login successfully")
public void user_should_be_able_to_login_successfully() {
	
	 String a = driver.findElement(parser.getbjectLocator("myaccountbutton")).getText();
	 System.out.println("Username is"+a);
	 Boolean bb = a.contentEquals("ANju");
	 Assert.assertTrue(bb);
	 System.out.println("Successfully logged to application");
	
}

@Then("the user is in searched item page")
@Then("the searched {string} items should get displayed")
public void the_searched_items_should_get_displayed(String string) {
 
	String a = driver.findElement(parser.getbjectLocator("searchresulttext")).getText();
    Boolean bb = a.contains(string);
    Assert.assertTrue(bb);
	System.out.println("Successfully logged to application");	
}


@Then("the item details should get displayed in next tab")
public void the_item_details_should_get_displayed_in_next_tab() {
	String parentWindow = driver.getWindowHandle();
	Set<String> allWindows = driver.getWindowHandles();
int a = allWindows.size();
Boolean b= a==2;
Assert.assertTrue(b);
ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
driver.switchTo().window(tabs2.get(1));



}

@Then("item should get displayed in the cart")
public void item_should_get_displayed_in_the_cart() {
  
	String a = driver.findElement(parser.getbjectLocator("cartitemnumber")).getText();
	
	Boolean an = a.contentEquals("1");
	 Assert.assertTrue(an);
		System.out.println("Item displayed in the cart");	

}

@Then("the user will get navigated to payment page")
public void the_user_will_get_navigated_to_payment_page() {
    WebElement aa = driver.findElement(parser.getbjectLocator("cartitemnumber"));
    Boolean bb = aa.isDisplayed();
    Assert.assertTrue(bb);
	System.out.println("the user  get navigated to payment page");	

}



@Then("the used should be able to log out from the application successfully")
public void the_used_should_be_able_to_log_out_from_the_application_successfully() {
	WebElement aa = driver.findElement(parser.getbjectLocator("loginbutton"));
    Boolean bb = aa.isDisplayed();
    Assert.assertTrue(bb);
	System.out.println("the user able to log out from the application successfully");	

}


}